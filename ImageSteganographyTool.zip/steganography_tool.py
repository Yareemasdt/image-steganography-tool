
import tkinter as tk
from tkinter import filedialog, messagebox
from tkinter import ttk
from PIL import Image, ImageTk
import threading
import os

class SteganographyApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Advanced Image Steganography Tool")
        self.root.geometry("600x1000")
        self.root.configure(bg="#f0f2f5")
        
        self.original_image = None
        self.stego_image = None
        self.max_message_size = 0
        self.encoded_image_path = ""

        self.style = ttk.Style()
        self.style.configure('TButton', font=('Helvetica', 12), padding=6)
        self.style.configure('Header.TLabel', font=('Helvetica', 18, 'bold'))
        self.style.configure('Section.TLabel', font=('Helvetica', 12, 'bold'))

        self.setup_ui()

    def setup_ui(self):
        main_frame = tk.Frame(self.root, bg="#8DB8A0", padx=20, pady=10)
        main_frame.pack(expand=True, fill="both")

        header = ttk.Label(main_frame, text="Image Steganography Tool", style='Header.TLabel', background="#F7F7F7")
        header.pack(pady=(0, 20))

        img_frame = tk.LabelFrame(main_frame, text=" Image Selection ", font=('Helvetica', 11, 'bold'), 
                                bg="#ffffff", padx=5, pady=5)
        img_frame.pack(fill="x", pady=2)

        self.load_button = ttk.Button(img_frame, text="Load Cover Image", command=self.load_image)
        self.load_button.pack(pady=2)

        self.image_info_label = tk.Label(img_frame, text="No image loaded", bg="#f0f2f5", fg="#555")
        self.image_info_label.pack()

        self.original_panel = tk.Label(img_frame, bg="#ddd", width=15, height=5)
        self.original_panel.pack(pady=10)

        msg_frame = tk.LabelFrame(main_frame, text=" Secret Message ", font=('Helvetica', 11, 'bold'), 
                                bg="#f0f2f5", padx=10, pady=3)
        msg_frame.pack(fill="x", pady=5)

        self.message_entry = tk.Text(msg_frame, height=2, width=50, font=('Helvetica', 11), wrap="word")
        self.message_entry.pack(pady=5)

        encode_frame = tk.Frame(main_frame, bg="#f0f2f5")
        encode_frame.pack(fill="x", pady=10)

        self.encode_button = ttk.Button(encode_frame, text="Encode Message", state="disabled", command=self.encode_message)
        self.encode_button.pack(side="left", padx=5)

        self.save_button = ttk.Button(encode_frame, text="Save Stego Image", state="disabled", command=self.save_stego_image)
        self.save_button.pack(side="left", padx=5)

        stego_frame = tk.LabelFrame(main_frame, text=" Stego Image ", font=('Helvetica', 11, 'bold'), 
                                  bg="#ffffff", padx=5, pady=5)
        stego_frame.pack(fill="x", pady=2)

        self.stego_panel = tk.Label(stego_frame, bg="#ddd", width=15, height=5)
        self.stego_panel.pack(pady=2)

        decode_frame = tk.Frame(main_frame, bg="#f0f2f5")
        decode_frame.pack(fill="x", pady=10)

        self.decode_button = ttk.Button(decode_frame, text="Load Stego Image & Decode", command=self.load_stego_image)
        self.decode_button.pack(side="left", padx=5)

        decoded_msg_frame = tk.LabelFrame(main_frame, text=" Decoded Message ", font=('Helvetica', 11, 'bold'), 
                                        bg="#f0f2f5", padx=10, pady=10)
        decoded_msg_frame.pack(fill="x", pady=5)

        self.decoded_text = tk.Text(decoded_msg_frame, height=2, width=50, font=('Helvetica', 11), wrap="word", state="disabled")
        self.decoded_text.pack(pady=5)

        self.status_var = tk.StringVar()
        self.status_bar = tk.Label(main_frame, textvariable=self.status_var, relief="sunken", anchor="w", bg="#f0f2f5", fg="#333")
        self.status_bar.pack(fill="x", pady=(10, 0))

    def load_image(self):
        path = filedialog.askopenfilename(title="Select cover image", filetypes=[("Image files", ".png;.jpg;.jpeg;.bmp")])
        if not path:
            return
        try:
            self.original_image = Image.open(path)
            width, height = self.original_image.size
            self.max_message_size = int((width * height * 3) / 8)
            preview = self.original_image.copy()
            preview.thumbnail((300, 300))
            photo = ImageTk.PhotoImage(preview)
            self.original_panel.configure(image=photo)
            self.original_panel.image = photo
            self.image_info_label.config(text=f"{os.path.basename(path)} ({width}x{height}) - Max message: {self.max_message_size} bytes")
            self.encode_button.config(state="normal")
            self.status_var.set(f"Loaded cover image: {os.path.basename(path)}")
        except Exception as e:
            messagebox.showerror("Error", f"Failed to load image: {str(e)}")

    def encode_message(self):
        message = self.message_entry.get("1.0", "end-1c")
        if not message:
            messagebox.showwarning("No message", "Please enter a message to encode")
            return
        if len(message.encode('utf-8')) > self.max_message_size:
            messagebox.showerror("Message too large", f"Maximum message size is {self.max_message_size} bytes")
            return
        self.status_var.set("Encoding message...")
        self.root.update()
        threading.Thread(target=self._encode_message_thread, args=(message,), daemon=True).start()

    def _encode_message_thread(self, message):
        try:
            binary_message = ''.join(format(ord(char), '08b') for char in message) + '00000000'
            img = self.original_image.copy()
            pixels = img.load()
            width, height = img.size
            binary_index = 0
            for row in range(height):
                for col in range(width):
                    if binary_index >= len(binary_message):
                        break
                    pixel = list(pixels[col, row])
                    for i in range(3):
                        if binary_index < len(binary_message):
                            pixel[i] = pixel[i] & ~1 | int(binary_message[binary_index])
                            binary_index += 1
                    pixels[col, row] = tuple(pixel)
                if binary_index >= len(binary_message):
                    break
            self.stego_image = img
            preview = img.copy()
            preview.thumbnail((300, 300))
            def update_ui():
                photo = ImageTk.PhotoImage(preview)
                self.stego_panel.configure(image=photo)
                self.stego_panel.image = photo
                self.save_button.config(state="normal")
                self.status_var.set("Message encoded successfully. Save the stego image.")
                messagebox.showinfo("Success", "Message encoded successfully. Now save the stego image.")
            self.root.after(0, update_ui)
        except Exception as e:
            self.root.after(0, lambda: messagebox.showerror("Encoding Error", f"Failed to encode message: {str(e)}"))

    def save_stego_image(self):
        if not self.stego_image:
            messagebox.showwarning("No image", "No stego image to save")
            return
        path = filedialog.asksaveasfilename(title="Save stego image", defaultextension=".png", filetypes=[("PNG files", "*.png")])
        if not path:
            return
        try:
            self.stego_image.save(path)
            self.encoded_image_path = path
            self.status_var.set(f"Stego image saved to {os.path.basename(path)}")
            self.message_entry.delete("1.0", "end")
            self.original_panel.config(image='', text='')
            self.original_panel.image = None
            self.image_info_label.config(text="No image loaded")
            self.original_image = None
            self.encode_button.config(state="disabled")
        except Exception as e:
            messagebox.showerror("Error", f"Failed to save image: {str(e)}")

    def load_stego_image(self):
        path = filedialog.askopenfilename(title="Select stego image", filetypes=[("Image files", ".png;.jpg;.jpeg;.bmp")])
        if not path:
            return
        try:
            img = Image.open(path)
            preview = img.copy()
            preview.thumbnail((300, 300))
            photo = ImageTk.PhotoImage(preview)
            self.stego_panel.configure(image=photo)
            self.stego_panel.image = photo
            self.status_var.set("Decoding message...")
            threading.Thread(target=self._decode_message_thread, args=(img,), daemon=True).start()
        except Exception as e:
            messagebox.showerror("Error", f"Failed to load image: {str(e)}")

    def _decode_message_thread(self, img):
        try:
            binary_message = ""
            pixels = img.load()
            width, height = img.size
            for row in range(height):
                for col in range(width):
                    pixel = pixels[col, row]
                    for channel in pixel[:3]:
                        binary_message += str(channel & 1)
                    if len(binary_message) >= 8 and binary_message[-8:] == '00000000':
                        break
                else:
                    continue
                break
            message = ""
            for i in range(0, len(binary_message)-7, 8):
                byte = binary_message[i:i+8]
                if byte == '00000000':
                    break
                message += chr(int(byte, 2))
            def update_ui():
                self.decoded_text.config(state="normal")
                self.decoded_text.delete("1.0", "end")
                self.decoded_text.insert("1.0", message)
                self.decoded_text.config(state="disabled")
                self.status_var.set("Message decoded successfully")
            self.root.after(0, update_ui)
        except Exception as e:
            self.root.after(0, lambda: messagebox.showerror("Decoding Error", f"Failed to decode message: {str(e)}"))

if __name__ == "__main__":
    root = tk.Tk()
    app = SteganographyApp(root)
    root.mainloop()
