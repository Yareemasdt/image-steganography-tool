# Image Steganography Tool

A simple, beginner-friendly Python GUI tool for hiding and extracting secret text messages inside image files using LSB (Least Significant Bit) steganography.

## Features
- Load cover image
- Hide secret message into the image
- Save the stego image
- Decode hidden message from a stego image

## Requirements
- Python 3.x
- Pillow

## How to Run
```
python steganography_tool.py
```

## Author
Built by a cybersecurity student as a university final-year project.
